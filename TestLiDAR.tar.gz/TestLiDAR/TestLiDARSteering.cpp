
extern "C" {
    #include <rc_usefulincludes.h>
	#include <roboticscape.h>
}

//#include "LIDARSteeringAngle.h"
#include "URG04LX.hpp"

static const char * DEVICE = "/dev/ttyACM0";

int main(int argc, char *argv[]){
	float timeStep = 0.0025; // Time step of program, (seconds).
	int timeStepCount = 0;
	float timeElapsed = 0;
	double steerBias = -0.125;
	double steeringSaturationAngle = 30; // degrees
	double steeringRateLimit = 200; // degrees per second
	double steeringAngleOriginal = 0.0;
	double steeringAngle = 0.0;
	double lastSteeringAngle = 0;

	uint64_t startTimerNanoSeconds;

	// okay, off we go!
	// initialize hardware first
	if(rc_initialize()){
		fprintf(stderr,"ERROR: failed to run rc_initialize(), are you root?\n");
		return -1;
	}

	// Initialize the steering to zero.
	rc_send_servo_pulse_normalized(1, 0.0);

	// Initialize LIDAR
	URG04LX laser;
	laser.connect(DEVICE);
	
	// Main loop runs at 100 Hz
	while(rc_get_state()!=EXITING)
	{
		startTimerNanoSeconds = rc_nanos_since_boot();
		
		// Call the LIDAR processing function to get steering angle
////////// JARED, you should try to link up your functions in getSteeringAngleFromLIDAR //////////////////
////////// Feel free to modify it.                                                      //////////////////

		// Get a steering angle at 10Hz
		if (timeStepCount % 40 == 0)
		{
		double goalPointX = 0;
		double goalPointY = -20;
		steeringAngleOriginal = laser.getSteeringAngle(goalPointX, goalPointY);
		steeringAngle = steeringAngleOriginal;
		}

    	//double steeringAngle = 0.4;
    
    	// Saturate the steering angle
    	if (steeringAngle > steeringSaturationAngle)
    	{
    	    steeringAngle = steeringSaturationAngle;
    	}
    	if (steeringAngle < -steeringSaturationAngle)
    	{
        	steeringAngle = -steeringSaturationAngle;
    	}
    
    	// Rate limit the steering angle
    	double strRateLim_timeStep = steeringRateLimit * timeStep;
    	if ((steeringAngle - lastSteeringAngle) > strRateLim_timeStep)
    	{
    	    steeringAngle = lastSteeringAngle + strRateLim_timeStep;
    	}
    	if ((-steeringAngle + lastSteeringAngle) > strRateLim_timeStep)
    	{
    	    steeringAngle = lastSteeringAngle - strRateLim_timeStep;
    	}
        
    	lastSteeringAngle = steeringAngle;
    	
    	// Convert from steering angle to PWM
    	double steeringSlope = (0.7 - (-0.7)) / (30 - (-25)) ; // (y2 - y1) / (x2 - x1)
    	double steeringPWMdouble = -1*steeringSlope*steeringAngle + steerBias;
    	float steeringPWM = (float)steeringPWMdouble;

		// Send steering and velocity command
		rc_send_servo_pulse_normalized(1, steeringPWM);

		// Print data to screen, but only once a second
		if (timeStepCount % 400 == 0)
		{
		printf("\r");
		printf("%7.2f | %f ",timeElapsed, steeringAngleOriginal);
		fflush(stdout);
		}

		timeElapsed += timeStep;
		timeStepCount++;
		
		// Stay in this loop until the amount of time for the loop has reached timeStep
		while ( (rc_nanos_since_boot() - startTimerNanoSeconds) < ( (uint64_t) (timeStep * 1000000000)) )
		{
		}
	}
	
	rc_send_servo_pulse_normalized(1, 0);
	rc_cleanup();
	return 0;
}

