/**
*
* URGPlotter.cpp - C++ code for BreezyLidar URG04LX class
*
*/

#include "URG04LX.hpp"

#include "hokuyo.h"

URG04LX::URG04LX(const bool debug)
{
    this->hokuyo = hokuyo_create("URG04LX::URG04LX", debug);
}

URG04LX::~URG04LX()
{
    hokuyo_destroy(this->hokuyo, "URG04LX::~URG04LX");
}

int URG04LX::connect(const std::string device, int baud_rate)
{
    return hokuyo_connect(this->hokuyo, "URG04LX::connect", (char *)device.c_str(), baud_rate);    

}
  
int URG04LX::getScan(unsigned int * range)
{        
    return hokuyo_get_scan(this->hokuyo, "URG04LX::getScan", range);
}

double URG04LX::getMaxAngle()
{
	return hokuyo_get_angle_max(this->hokuyo);
}

double URG04LX::getMinAngle()
{
	return hokuyo_get_angle_min(this->hokuyo);
}

double URG04LX::getAngleRes()
{
	return hokuyo_get_angle_res(this->hokuyo);
}

ostream& operator<< (ostream & out, URG04LX & urg)
{
    char str[1000];
    
    hokuyo_get_str(urg.hokuyo, "ostream& operator<<", str);
        
    out << str;
    
    return out;
}

double URG04LX::getSteeringAngle(double goalPointX, double goalPointY) {
    unsigned int ranges[682];
    double angles[682];

    double minAngle  = -2.08621;
    double angleRes  = 0.00613592;

    int ndata = getScan(ranges);

    double angleSteer = 0.0;

    if (ndata) 
    {
        // Initialize vector components
        double dXA = 0;      // Attractive force to goal (x-component)
        double dYA = 0;      // Attractive force to goal (y-component)

        double dXRSum = 0;   // Repulsive force from obstacles (x-component)
        double dYRSum = 0;   // Repulsive force from obstacles (y-component)

        double dXARSum = 0;  // Steering vector (x-component)
        double dYARSum = 0;  // Steering vector (y-component)

        // Calculate angles
        CalculateAngles(682, angles, minAngle, angleRes);

        // Calculate attractive force to goal
        CalculateAttractiveForceToGoal(goalPointX, goalPointY, dXA, dYA);

        // Calculate repulsive force from obstacles
        CalculateRepulsiveForceFromObs(angles, ranges, ndata, dXRSum, dYRSum);

        // Calculate steering angle from attractive and repulsive forces
        angleSteer = CalculateSteeringAngle(dXRSum, dYRSum, dXA, dYA, dXARSum, dYARSum);
    }
    else
    {
        printf("=== SCAN FAILED ===\n");
    }

    return angleSteer;
}

void URG04LX::CalculateAngles(int scanLength, double* angles, double minAngle, double angleRes){
    for(int i = 0; i<scanLength; i++){
        angles[i] = minAngle + i*angleRes;
    }
}

void URG04LX::CalculateAttractiveForceToGoal(double goalPointX, double goalPointY, double &dXA, double &dYA){
    dXA = goalPointY;
    dYA = goalPointX;
    double fNorm    = sqrt( dXA*dXA + dYA*dYA );
    dXA = dXA/fNorm;
    dYA = dYA/fNorm;
}

void URG04LX::CalculateRepulsiveForceFromObs(double* angles, unsigned int* ranges, int scanLength, double &dXRSum, double &dYRSum){
    // Angles and Ranges
    double min_angle = -PI/2;
    double max_angle = PI/2;
    double min_range = 10;
    double max_range = 200;

    double fx, fy;
    double fxSum = 0.0;
    double fySum = 0.0;


    for(int i = 0; i<scanLength; i++){                          // For each obstacle point
        if(ranges[i] >= 10*min_range && ranges[i] <= 10*max_range && angles[i] > min_angle && angles[i] < max_angle){       // If distance is in preferred range...

            fx = -1.0/(ranges[i])*sin(angles[i]-PI/2.0);    // Sum repulsive force x-component 
            fy = 1.0/(ranges[i])*cos(angles[i]-PI/2.0); // Sum repulsive force y-component
        }
        else{ // Else if distance is not in preferred range...
            fx = 0.0;   // Do not contribute an x-component
            fy = 0.0;   // Do not contribute a y-component
        }

        fxSum = fxSum + fx;
        fySum = fySum + fy;
    }

    double fNorm    = sqrt( fxSum*fxSum + fySum*fySum );
    
    if(fNorm > 0){
        dXRSum = fxSum/fNorm;
        dYRSum = fySum/fNorm;
    }
    else{
        dXRSum = 0;
        dYRSum = 0;
    }
}

double URG04LX::CalculateSteeringAngle(double dXRSum, double dYRSum, double dXA, double dYA, double &dXARSum, double &dYARSum){
    double dXARSumRaw = dXRSum + 3*dXA;
    double dYARSumRaw = dYRSum + 3*dYA;

    double dARSumNorm = sqrt( dXARSumRaw*dXARSumRaw + dYARSumRaw*dYARSumRaw );

    if(dARSumNorm > 0){
        dXARSum = dXARSumRaw/dARSumNorm;
        dYARSum = dYARSumRaw/dARSumNorm;
    }
    else{
        dXARSum = 0;
        dYARSum = 0;
    }

    double angleSteer = (atan2 (dXARSum,dYARSum) + PI/2)*(180/PI);

    return angleSteer;
}